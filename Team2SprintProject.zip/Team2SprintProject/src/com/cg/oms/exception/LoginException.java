package com.cg.oms.exception;

public class LoginException {

}
