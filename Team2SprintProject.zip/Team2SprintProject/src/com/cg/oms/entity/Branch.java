package com.cg.oms.entity;

public class Branch 
{
	private int branchId;
	private String branchName;
	private String branchDescription;
	
}
