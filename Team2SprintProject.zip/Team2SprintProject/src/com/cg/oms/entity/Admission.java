package com.cg.oms.entity;

public class Admission
{
	private String emailId;
	private String applicationId;
	private String admissionStatus;//Confirm after payement done;
	private College college;
	private Program program;
	private Course course;
	private String year;

}
