package com.cg.oms.entity;

import java.time.LocalDate;

public class Payment 
{
	private int paymentId;
	private String emailIdOfStudent;
	private String applicationId;
	private double paymentAmount;
	private String paymentDescription;
	private LocalDate paymentDate;
	private String paymentStatus;
	

}
