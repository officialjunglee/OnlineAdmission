package com.cg.oms.entity;

public class Program
{
	private Integer programId;	
	private String programName;
	
	private String programDescription;
	
	private String programEligibility;
	
	private String programDuration;
	
	private String degreeOffered;
	
}