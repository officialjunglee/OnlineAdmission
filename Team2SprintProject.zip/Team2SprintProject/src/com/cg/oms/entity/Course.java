package com.cg.oms.entity;

import java.util.ArrayList;

public class Course 
{
	private int courseId;
	private String courseName;
	private String description;
	private String eligibility;
	private College college;
	private ArrayList<Branch> branches;
}
