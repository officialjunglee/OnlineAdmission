package main;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.oms.entity.Payment;
import com.cg.oms.repository.IPaymentRepository;
public class PaymentRepository implements IPaymentRepository{

	private EntityManagerFactory factory;
	
	public PaymentRepository() {
		factory= Persistence.createEntityManagerFactory("MySQLPU");
	}
	
	public Payment addPayment(Payment payment) {
		EntityManager em= factory.createEntityManager();
		
		try{
			EntityTransaction txn= em.getTransaction();
		
		txn.begin();
		em.persist(payment);
		txn.commit();
		return payment;
		}
		finally {
			em.close();
		}
	}

	public ArrayList<Payment> viewAllPaymentDetails() {
		EntityManager em= factory.createEntityManager();
		
		try {
		Query query=em.createQuery("from Payment");
		return (ArrayList<Payment>) query.getResultList();
		}
		finally
		{
			em.close();
		}
	}

	public ArrayList<Payment> getPaymentDetailsByEmail(String emailId) {
		EntityManager em= factory.createEntityManager();
		try {
		Query query=em.createQuery("Select * from Payment where emailIdOfStudent="+emailId);
		return (ArrayList<Payment>) query.getResultList();
		}
		finally
		{
			em.close();
		}
	}

	public Payment getPaymentDetailsByPaymentId(int paymentId) {
		EntityManager em= factory.createEntityManager();
		try {
		EntityTransaction txn= em.getTransaction();
		txn.begin();
		Payment payment= em.find(Payment.class, paymentId);
		txn.commit();
		return payment;
		}
		finally
		{
			em.close();	
		}
	}

	public Payment getPaymentDetailsByApplicationId(int applicationId) {
		EntityManager em= factory.createEntityManager();
		try {
		EntityTransaction txn= em.getTransaction();
		txn.begin();
		Payment payment= em.find(Payment.class, applicationId);
		txn.commit();
		return payment;
		}
		finally {
			em.close();	
		}
	}
	public ArrayList<Payment> getPayementDetailsByStatus(String paymentStatus) {
		EntityManager em= factory.createEntityManager();
		try {
		Query query=em.createQuery("Select * from Payment where paymentStatus="+paymentStatus);
		return (ArrayList<Payment>) query.getResultList();
		}
		finally
		{
			em.close();
		}
	}

	public int deletePaymentById(int paymentById) {
		EntityManager em= factory.createEntityManager();
		try {
			EntityTransaction txn= em.getTransaction();
			txn.begin();
			Payment payment= em.find(Payment.class, paymentById);
			em.remove(payment);
			txn.commit();
			return paymentById;
		}
		finally {
			em.close();
		}
	}

	public int updatePaymentDetails(Payment payment) {
		EntityManager em= factory.createEntityManager();
		try
		{
			EntityTransaction txn= em.getTransaction();
			txn.begin();
			em.merge(payment);
			txn.commit();
			return 0;
		}
		finally {
			em.close();	
		}
	}

}
