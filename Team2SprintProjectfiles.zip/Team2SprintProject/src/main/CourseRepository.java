package main;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.oms.entity.Course;
import com.cg.oms.repository.ICourseRepository;
public class CourseRepository implements ICourseRepository{
	
	private EntityManagerFactory factory;
	
	public CourseRepository() {
		factory= Persistence.createEntityManagerFactory("MySQLPU");
	}

	public Course addCourse(Course course) {
		EntityManager em= factory.createEntityManager();
		try {
			EntityTransaction txn= em.getTransaction();
			txn.begin();
			em.persist(course);
			txn.commit();
			return course;
		}
		finally {
			em.close();
		}
		
	}

	public ArrayList<Course> viewAllCourseDetails() {
		EntityManager em= factory.createEntityManager();
		try {
		Query query=em.createQuery("from Course");
		return (ArrayList<Course>) query.getResultList();
		}
		finally
		{
			em.close();
		}
	}

	public ArrayList<Course> getCourseDetailsByCourseName(String courceName) {
		EntityManager em= factory.createEntityManager();
		try {
		Query query=em.createQuery("Select * from Course where courseName="+courceName);
		return (ArrayList<Course>) query.getResultList();
		}
		finally
		{
			em.close();
		}
	}

	public ArrayList<Course> getCourseDetailsByCollegeName(String collegeName) {
		EntityManager em= factory.createEntityManager();
		try {
			Query query=em.createQuery("Select * from Course where college="+collegeName);
			return (ArrayList<Course>) query.getResultList();
			}
			finally
			{
				em.close();
			}
	}

	public ArrayList<Course> getCourseDetailsByEligibility(String eligibility) {
		EntityManager em= factory.createEntityManager();
		try {
			Query query=em.createQuery("Select * from Course where eligibility="+eligibility);
			return (ArrayList<Course>) query.getResultList();
			}
			finally
			{
				em.close();
			}
	}

	public Course getCourseDetailsByCourseId(int courceId) {
		EntityManager em= factory.createEntityManager();
		try
		{
			EntityTransaction txn= em.getTransaction();
			txn.begin();
			Course course= em.find(Course.class, courceId);
			txn.commit();
			return course;
		}
		finally {
			em.close();
		}
	}

	public int deleteCourseById(int courseById) {
		EntityManager em= factory.createEntityManager();
		try
		{
			EntityTransaction txn= em.getTransaction();
			txn.begin();
			Course course= em.find(Course.class, courseById);
			em.remove(course);
			txn.commit();
			return courseById;
		}
		finally {
			em.close();
		}
	}

	public int deleteCourseByName(String courseName) {
		EntityManager em= factory.createEntityManager();
		try {
			EntityTransaction txn= em.getTransaction();
			txn.begin();
			Course course= em.find(Course.class, courseName);
			em.remove(course);
			txn.commit();
			return 0;
		}
		finally 
		{
			em.close();
		}
	}

	public int updateCourseDetails(Course course) {
		EntityManager em= factory.createEntityManager();
		try
		{
			EntityTransaction txn= em.getTransaction();
			txn.begin();
			em.merge(course);
			txn.commit();
			return 0;
		}
		finally
		{
			em.close();
		}
	}

}
