package main;

import java.util.ArrayList;

import com.cg.oms.entity.Course;
import com.cg.oms.repository.ICourseRepository;
import com.cg.oms.service.ICourseService;
public class CourseService implements ICourseService{
	
	private ICourseRepository repo;
	public CourseService()
	{
		repo = new CourseRepository();
	}
	public Course addCourse(Course course) {
		
		return repo.addCourse(course);
	}

	public ArrayList<Course> viewAllCourseDetails() {
		return repo.viewAllCourseDetails();
	}

	public ArrayList<Course> getCourseDetailsByCourseName(String courceName) {
		return repo.getCourseDetailsByCourseName(courceName);
	}

	public ArrayList<Course> getCourseDetailsByCollegeName(String collegeName) {
		return repo.getCourseDetailsByCollegeName(collegeName);
	}

	public ArrayList<Course> getCourseDetailsByEligibility(String eligibility) {
		return repo.getCourseDetailsByEligibility(eligibility);
	}

	public Course getCourseDetailsByCourseId(int courceId) {
		
		return repo.getCourseDetailsByCourseId(courceId);
	}

	public int deleteCourseById(int courseById) {
		return repo.deleteCourseById(courseById);
	}

	public int deleteCourseByName(String courseName) {
		return repo.deleteCourseByName(courseName);
	}

	public int updateCourseDetails(Course course) {
		return repo.updateCourseDetails(course);
	}
	

}
