package main;

import java.util.ArrayList;

import com.cg.oms.entity.Payment;
import com.cg.oms.repository.IPaymentRepository;
import com.cg.oms.service.IPaymentService;

public class PaymentService implements IPaymentService {
	private IPaymentRepository repo;
	
	public PaymentService()
	{
		repo = new PaymentRepository();
	}

	public Payment addPayment(Payment payment) {
		
		return repo.addPayment(payment);
	}

	public ArrayList<Payment> viewAllPaymentDetails() {
		return repo.viewAllPaymentDetails();
	}

	public ArrayList<Payment> getPaymentDetailsByEmail(String emailId) {
		return repo.getPaymentDetailsByEmail(emailId);
	}

	public Payment getPaymentDetailsByPaymentId(int paymentId) {
		return repo.getPaymentDetailsByPaymentId(paymentId);
	}

	public Payment getPaymentDetailsByApplicationId(int applicationId) {
		return repo.getPaymentDetailsByApplicationId(applicationId);
	}

	public ArrayList<Payment> getPayementDetailsByStatus(String paymentStatus) {
		return repo.getPayementDetailsByStatus(paymentStatus);
	}

	public int deletePaymentById(int paymentById) {
		return repo.deletePaymentById(paymentById);
	}

	public int updatePaymentDetails(Payment payment) {
		return repo.updatePaymentDetails(payment);
	}
	

}
