package com.cg.oms.entity;

import java.util.ArrayList;

public class College
{
	private int collegeRegId;
	private String collegeName;
	private Address collegeAddress;	
	private ArrayList<Program> programList;
	private ArrayList<Course> courseList;
	private ArrayList<Branch> branchList;	
	private University universityName;
	public int getCollegeRegId() {
		return collegeRegId;
	}
	public void setCollegeRegId(int collegeRegId) {
		this.collegeRegId = collegeRegId;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public Address getCollegeAddress() {
		return collegeAddress;
	}
	public void setCollegeAddress(Address collegeAddress) {
		this.collegeAddress = collegeAddress;
	}
	public ArrayList<Program> getProgramList() {
		return programList;
	}
	public void setProgramList(ArrayList<Program> programList) {
		this.programList = programList;
	}
	public ArrayList<Course> getCourseList() {
		return courseList;
	}
	public void setCourseList(ArrayList<Course> courseList) {
		this.courseList = courseList;
	}
	public ArrayList<Branch> getBranchList() {
		return branchList;
	}
	public void setBranchList(ArrayList<Branch> branchList) {
		this.branchList = branchList;
	}
	public University getUniversityName() {
		return universityName;
	}
	public void setUniversityName(University universityName) {
		this.universityName = universityName;
	}
}
